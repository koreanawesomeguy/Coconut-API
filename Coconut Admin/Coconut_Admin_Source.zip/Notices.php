<?php
    require('Notices.html');
?>