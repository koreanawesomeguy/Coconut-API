<?php
    $_TYPE = isset($_SERVER['QUERY_STRING']) ? 'MAIN' : 'ADD';

    if ($_TYPE == 'ADD') {
        require('AddAdmin.html');
    } else {
        require('ManageAdmin.html');
    }
?>