function connectServer(url, data, callback) {
    var settings = {
        "url": url,
        "method": "POST",
        "timeout": 0,
        "headers": {
            "Content-Type": "text/plain"
        },
        "data": data
    };

    var approveList = [
        '3000', // Success
        '3804', // No Transaction Information
        '4202', // KYC Approve Fail
        '3806', // No Intro Image Exist
        '4506', // KYC Alreay approved
        '4300',// There is no account
        '4400' // need approve kyc first
    ]

    $.ajax(settings).done(function(json) {
        if (callback != null || callback != undefined) {
            if (approveList.indexOf(json.status) !== -1) {
                callback(json);
            } else if (json.status === "4500") {
                console.log("권한 없음.")
                alert('권한이 없습니다.');
            } else {
                callback(json);
            }
        }
    }).fail(function(xhr, status, errorThrown) {
        console.log(xhr);
        console.log(status);
        console.log(errorThrown);
    })
}