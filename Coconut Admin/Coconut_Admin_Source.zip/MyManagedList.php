<?php
    require('MyManagedList.html');
?>