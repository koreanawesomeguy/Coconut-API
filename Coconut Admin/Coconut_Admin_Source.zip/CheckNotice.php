<?php
    $_NOTICE_ID = $_SERVER['QUERY_STRING'];
    require('./CheckNotice.html');
?>