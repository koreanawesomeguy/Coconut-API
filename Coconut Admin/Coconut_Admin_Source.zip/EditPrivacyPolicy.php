<?php
    require('EditPrivacyPolicy.html');
?>