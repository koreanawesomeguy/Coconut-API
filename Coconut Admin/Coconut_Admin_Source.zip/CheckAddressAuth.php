<?php
    require('CheckAddressAuth.html');
?>