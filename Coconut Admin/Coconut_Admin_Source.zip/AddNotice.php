<?php
    require('AddNotice.html');
?>