<?php
    require('ServicePolicy.html');
?>