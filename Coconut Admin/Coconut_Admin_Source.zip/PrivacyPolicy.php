<?php
    require('PrivacyPolicy.html');
?>