<?php
    require('EditTerms.html');
?>