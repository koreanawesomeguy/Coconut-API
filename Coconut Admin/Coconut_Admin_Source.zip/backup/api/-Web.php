<?php




    









    /*

    function CheckCallerAndSession()
    {
        // check caller
        if(explode('/', $_SERVER['HTTP_REFERER'])[2] !== $_SERVER['HTTP_HOST'])
            return FALSE;



        // check session
        session_start();
        if($_SESSION['GAT'] == "")
            return FALSE;


        echo("OK");
    }



    function GetMyGoogleAccount()
    {
        // check GAT
        $MyInfo = file_get_contents("https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=" . $_SESSION["GAT"]);
        if($MyInfo == FALSE )
            return FALSE;
        if(strpos($MyInfo, "invalid_token") != 0)
            return FALSE;

        $GoogleAccount = json_decode($MyInfo);
        return $GoogleAccount->{'user_id'} . "/" . $GoogleAccount->{'email'};
    }





    //define("_KYCPhotosFolderPath", "/KYCPhotos/");

    function CheckSecurity()
    {
        // check caller
        if(explode('/', $_SERVER['HTTP_REFERER'])[2] !== $_SERVER['HTTP_HOST'])
            return FALSE;

        // check session
        session_start();
        if($_SESSION["GAT"] == "")
            return FALSE;

        // check GAT
        $GATInfo = file_get_contents("https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=" . $_SESSION["GAT"]);
        if($GATInfo == FALSE )
            return FALSE;
        if(strpos($GATInfo, "invalid_token") != 0)
            return FALSE;

        // return info
        $GoogleAccount = json_decode($GATInfo);
        return $GoogleAccount->{'user_id'} . "/" . $GoogleAccount->{'email'};
    }
    */







?>