<?php
    echo(file_get_contents("https://4xgirw2kmc.execute-api.us-east-2.amazonaws.com/GetClients?GAT=" . $_GET['GAT']));
?>