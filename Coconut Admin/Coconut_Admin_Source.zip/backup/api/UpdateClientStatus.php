<?php
    echo(file_get_contents("https://nj54oq5eh3.execute-api.us-east-2.amazonaws.com/UpdateClient?GAT=" . $_GET['GAT'] . "&GAE=" . $_GET["ClientGAE"] . "&Key=Status&Value=" . $_GET["NewStatus"]));
?>