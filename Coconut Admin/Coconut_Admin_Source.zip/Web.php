<?php
    // check referer
	if(explode('/', $_SERVER['HTTP_REFERER'])[2] !== $_SERVER['HTTP_HOST'])
        return;

    // set Content
	switch($_POST['API'])
	{
        case 'GetCoconutAdminInfo': $Content = json_encode(array('GAT'=>$_POST['GAT'])); break;
    }

    // call api
    $Context = stream_context_create(array('http'=>array('method'=>'POST', 'content'=>$Content, 'header'=>"Content-Type:application/json\r\n" . "Accept:application/json\r\n" . "Content-Length:" . strlen($Content))));
    echo(file_get_contents("https://tdz1cyc2t5.execute-api.us-east-2.amazonaws.com/" . $_POST['API'], false, $Context));
?>