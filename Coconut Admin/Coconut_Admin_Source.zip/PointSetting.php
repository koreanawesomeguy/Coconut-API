<?php
    require('PointSetting.html');
?>