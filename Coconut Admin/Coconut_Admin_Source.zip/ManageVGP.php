<?php
    require('ManageVGP.html');
?>