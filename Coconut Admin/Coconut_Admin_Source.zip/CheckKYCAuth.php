<?php
    require('CheckKYCAuth.html');
?>