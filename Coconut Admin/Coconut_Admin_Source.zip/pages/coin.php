<?php
    $_coin_name = isset($_POST['coin-name']) ? $_POST['coin-name'] : 'null';
    $_coin_address = isset($_POST['coin-address']) ? $_POST['coin-address'] : 'null';
    if ($_coin_name == 'null') {
        echo ('잘못된 페이지 접근입니다.');
    } else {
        if ($_POST['page-id'] == 'coin-detail') {
            require('./html/coin/coin_detailstransaction_history.html');
        } else if ($_POST['page-id'] == 'send-coin') {
            require('./html/coin/send_money.html');
        } else if ($_POST['page-id'] == 'receive-coin') {
            require('./html/coin/receiving_money.html');
        } else if ($_POST['page-id'] == 'charge-coin') {
            if ($_coin_name == 'GHD') {
                require('./html/coin/GHUB_to_GHD_switch.html');
            } else if ($_coin_name == 'VGP') {
                require('./html/coin/VGRX_to_VGP_switch.html');
            } else {
                echo ('잘못된 페이지 접근입니다.');
            }
        } else {
            echo ('잘못된 페이지 접근입니다.');
        }
    }
?>