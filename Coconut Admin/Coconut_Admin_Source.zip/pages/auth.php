<?php
    if ($_POST['page-id'] == 'passport-verification') {
        require('./html/securityauth/passport_verification.html');
    } else if ($_POST['page-id'] == 'passport-verification-2') {
        require('./html/securityauth/passport_verification_2.html');
    } else if ($_POST['page-id'] == 'passport-verification-3') {
        require('./html/securityauth/passport_verification_3.html');
    } else if ($_POST['page-id'] == 'passport-verification-4') {
        require('./html/securityauth/passport_verification_4.html');
    } else if ($_POST['page-id'] == 'address-authentication') {
        require('./html/securityauth/address_authentication.html');
    } else if ($_POST['page-id'] == 'security-level-limitation') {
        require('./html/securityauth/security_level_limitation.html');
    } else {
        echo ('잘못된 페이지 접근입니다.');
    }
?>