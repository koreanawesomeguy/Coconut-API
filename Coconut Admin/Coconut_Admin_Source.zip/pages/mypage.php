<?php
    $_security_level = isset($_POST['security-level']) ? $_POST['security-level'] : null;
    $_security_status_level = isset($_POST['security-status-level']) ? $_POST['security-status-level'] : null;
    if ($_POST['page-id'] == 'vrgx-payment') {
        require('./html/mypage/VRGX_payment_method.html');
    } else if ($_POST['page-id'] == 'vrgx-purchase') {
        require('./html/mypage/VRGX_purchase_method.html');
    } else if ($_POST['page-id'] == 'my-info') {
        require('./html/mypage/my_info.html');
    } else if ($_POST['page-id'] == 'login-history') {
        require('./html/mypage/login_history.html');
    } else if ($_POST['page-id'] == 'frequency-address-list') {
        require('./html/mypage/frequency_address_list.html');
    } else if ($_POST['page-id'] == 'add-address-coin') {
        require('./html/mypage/add_address_coin.html');
    } else if ($_POST['page-id'] == 'add-address-detail') {
        require('./html/mypage/add_address_detail.html');
    } else if ($_POST['page-id'] == 'service-terms-and-policy') {
        require('./html/mypage/service_terms_and_policy.html');
    } else if ($_POST['page-id'] == 'service-operation-policy') {
        require('./html/mypage/service_operation_policy.html');
    } else if ($_POST['page-id'] == 'privacy-policy') {
        require('./html/mypage/privacy_policy.html');
    } else if ($_POST['page-id'] == 'security-level') {
        require('./html/mypage/security_level.html');
    } else if ($_POST['page-id'] == 'total-transaction-history') {
        require('./html/mypage/total_transaction_history.html');
    } else if ($_POST['page-id'] == 'setting') {
        require('./html/mypage/setting.html');
    } else if ($_POST['page-id'] == 'notice-list') {
        require('./html/mypage/notice_list.html');
    } else if ($_POST['page-id'] == 'notice-detail') {
        require('./html/mypage/notice_detail.html');
    }
    else {
        echo ('잘못된 페이지 접근입니다.');
    }
?>