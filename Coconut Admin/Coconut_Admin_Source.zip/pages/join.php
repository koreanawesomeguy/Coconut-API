<?php
    if ($_POST['page-id'] == 'user-agreement') {
        $_agreement_type = isset($_POST['agreement-type']) ? $_POST['agreement-type'] : 'empty';

        if ($_agreement_type == 'email') {
            require('./html/join/member_agree_email.html');
        } else if ($_agreement_type == 'facebook') {
            require('./html/join/member_agree_facebook.html');
        }
    } else if ($_POST['page-id'] == 'user-register') {
        //약관 동의 여부 체크
        $_agree_access_terms = isset($_POST['is-access-terms']) ? $_POST['is-access-terms'] : 'false';
        $_agree_privacy_policy = isset($_POST['is-privacy-policy']) ? $_POST['is-privacy-policy'] : 'false';
        
        if ($_agree_access_terms == 'true' && $_agree_privacy_policy == 'true') {
            $_user_join_type = isset($_POST['user-join-type']) ? $_POST['user-join-type'] : 'empty';
            if ($_user_join_type == 'email') {
                require('./html/join/member_join_email.html');
            } else if ($_user_join_type == 'facebook') {
                require('./html/join/member_join_facebook.html');
            } else {
                echo ('잘못된 페이지 접근입니다.');
            }
        } else {
            echo ('잘못된 페이지 접근입니다.');
        }
    } else if ($_POST['page-id'] == 'user-change-pw') {
        require('./html/join/member_find_pw.html');
    } else if ($_POST['page-id'] == 'user-change-pw-fail') {
        require('./html/join/member_find_pw_f.html');
    } else if ($_POST['page-id'] == 'user-change-pw-success') {
        require('./html/join/member_find_pw_s.html');
    } else {
        echo ('잘못된 페이지 접근 입니다.');
    }
?>