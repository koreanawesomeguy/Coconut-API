<?php
    require('Terms.html');
?>