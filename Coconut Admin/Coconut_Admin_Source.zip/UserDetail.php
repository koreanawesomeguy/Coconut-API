<?php
    $_USER_EMAIL = $_SERVER['QUERY_STRING'];
    require('./UserDetail.html');
?>