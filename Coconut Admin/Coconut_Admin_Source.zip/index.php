<?php
    $_GAT = $_GET['GAT'];
    require('GAT.html');
?>